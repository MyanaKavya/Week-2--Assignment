var alphabet = prompt('Enter your option between A to D');
switch (alphabet) {
    case 'A':
        alert("Excellent");
        break;
    case 'B':
        alert("Good");
        break;
    case 'C':
        alert("Fair");
        break;
    case 'D':
        alert("Poor");
        break;
    default:
        alert("Invalid Input");
}
